﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QUANLYQUANNHAU
{
    internal class MonAn
    {

        string tenMA;
        int sL;
        string giatien;
        public string TenMA { get => tenMA; set => tenMA = value; }
        public int SL { get => sL; set => sL = value; }
        public string Giatien { get => giatien; set => giatien = value; }
    }
}
