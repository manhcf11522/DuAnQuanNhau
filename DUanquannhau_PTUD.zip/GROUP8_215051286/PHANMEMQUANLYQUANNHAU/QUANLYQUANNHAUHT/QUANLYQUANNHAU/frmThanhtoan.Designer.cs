﻿namespace QUANLYQUANNHAU
{
    partial class frmThanhtoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lvsThanhToan = new System.Windows.Forms.ListView();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTenBan = new System.Windows.Forms.Label();
            this.lblTenKH = new System.Windows.Forms.Label();
            this.lblMaHD = new System.Windows.Forms.Label();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.lblTT = new System.Windows.Forms.Label();
            this.btnTT = new System.Windows.Forms.Button();
            this.btnSuaOrder = new System.Windows.Forms.Button();
            this.btnHuyTT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(2, -1);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(808, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "THANH TOÁN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(23, 48);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 26);
            this.label3.TabIndex = 0;
            this.label3.Text = "Mã bàn:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 151);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Mã hóa đơn:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(259, 48);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Mã nhân viên:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(600, 163);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "TỔNG TIỀN:";
            // 
            // lvsThanhToan
            // 
            this.lvsThanhToan.HideSelection = false;
            this.lvsThanhToan.Location = new System.Drawing.Point(26, 213);
            this.lvsThanhToan.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lvsThanhToan.Name = "lvsThanhToan";
            this.lvsThanhToan.Size = new System.Drawing.Size(758, 281);
            this.lvsThanhToan.TabIndex = 2;
            this.lvsThanhToan.UseCompatibleStateImageBehavior = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 103);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tên khách hàng:";
            // 
            // lblTenBan
            // 
            this.lblTenBan.AutoSize = true;
            this.lblTenBan.Location = new System.Drawing.Point(97, 47);
            this.lblTenBan.Name = "lblTenBan";
            this.lblTenBan.Size = new System.Drawing.Size(52, 17);
            this.lblTenBan.TabIndex = 4;
            this.lblTenBan.Text = "label7";
            // 
            // lblTenKH
            // 
            this.lblTenKH.AutoSize = true;
            this.lblTenKH.Location = new System.Drawing.Point(155, 103);
            this.lblTenKH.Name = "lblTenKH";
            this.lblTenKH.Size = new System.Drawing.Size(52, 17);
            this.lblTenKH.TabIndex = 4;
            this.lblTenKH.Text = "label7";
            // 
            // lblMaHD
            // 
            this.lblMaHD.AutoSize = true;
            this.lblMaHD.Location = new System.Drawing.Point(155, 151);
            this.lblMaHD.Name = "lblMaHD";
            this.lblMaHD.Size = new System.Drawing.Size(52, 17);
            this.lblMaHD.TabIndex = 4;
            this.lblMaHD.Text = "label7";
            // 
            // lblMaNV
            // 
            this.lblMaNV.AutoSize = true;
            this.lblMaNV.Location = new System.Drawing.Point(400, 47);
            this.lblMaNV.Name = "lblMaNV";
            this.lblMaNV.Size = new System.Drawing.Size(52, 17);
            this.lblMaNV.TabIndex = 4;
            this.lblMaNV.Text = "label7";
            // 
            // lblTT
            // 
            this.lblTT.AutoSize = true;
            this.lblTT.Location = new System.Drawing.Point(732, 163);
            this.lblTT.Name = "lblTT";
            this.lblTT.Size = new System.Drawing.Size(52, 17);
            this.lblTT.TabIndex = 4;
            this.lblTT.Text = "label7";
            // 
            // btnTT
            // 
            this.btnTT.BackColor = System.Drawing.Color.Cyan;
            this.btnTT.Location = new System.Drawing.Point(26, 527);
            this.btnTT.Name = "btnTT";
            this.btnTT.Size = new System.Drawing.Size(181, 39);
            this.btnTT.TabIndex = 5;
            this.btnTT.Text = "Thanh Toán";
            this.btnTT.UseVisualStyleBackColor = false;
            this.btnTT.Click += new System.EventHandler(this.btnTT_Click);
            // 
            // btnSuaOrder
            // 
            this.btnSuaOrder.BackColor = System.Drawing.Color.Yellow;
            this.btnSuaOrder.Location = new System.Drawing.Point(300, 527);
            this.btnSuaOrder.Name = "btnSuaOrder";
            this.btnSuaOrder.Size = new System.Drawing.Size(181, 39);
            this.btnSuaOrder.TabIndex = 6;
            this.btnSuaOrder.Text = "Sửa Order";
            this.btnSuaOrder.UseVisualStyleBackColor = false;
            this.btnSuaOrder.Click += new System.EventHandler(this.btnSuaOrder_Click);
            // 
            // btnHuyTT
            // 
            this.btnHuyTT.BackColor = System.Drawing.Color.Red;
            this.btnHuyTT.Location = new System.Drawing.Point(603, 527);
            this.btnHuyTT.Name = "btnHuyTT";
            this.btnHuyTT.Size = new System.Drawing.Size(181, 39);
            this.btnHuyTT.TabIndex = 7;
            this.btnHuyTT.Text = "Hủy Thanh Toán";
            this.btnHuyTT.UseVisualStyleBackColor = false;
            this.btnHuyTT.Click += new System.EventHandler(this.btnHuyTT_Click);
            // 
            // frmThanhtoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(811, 612);
            this.Controls.Add(this.btnHuyTT);
            this.Controls.Add(this.btnSuaOrder);
            this.Controls.Add(this.btnTT);
            this.Controls.Add(this.lblTT);
            this.Controls.Add(this.lblMaNV);
            this.Controls.Add(this.lblMaHD);
            this.Controls.Add(this.lblTenKH);
            this.Controls.Add(this.lblTenBan);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lvsThanhToan);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmThanhtoan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thanh toán";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListView lvsThanhToan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTenBan;
        private System.Windows.Forms.Label lblTenKH;
        private System.Windows.Forms.Label lblMaHD;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.Label lblTT;
        private System.Windows.Forms.Button btnTT;
        private System.Windows.Forms.Button btnSuaOrder;
        private System.Windows.Forms.Button btnHuyTT;
    }
}